export const config = {
  apiKey: 'AIzaSyC9EuB2YkkXFe0KCnU-RzkbAY_ZeZsLvPY',
  authDomain: 'wts-trading-game.firebaseapp.com',
  databaseURL: 'https://wts-trading-game.firebaseio.com',
  projectId: 'wts-trading-game',
  storageBucket: 'wts-trading-game.appspot.com',
  messagingSenderId: '902954785891'
}
