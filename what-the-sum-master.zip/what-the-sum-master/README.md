# what-the-sum

> An educational finance game

Used: CloudFunctions, Firebase, FirebaseUI, Authentication, Hosting – (WTF-A-Trading-Game) on Google Cloud

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

### Vue-CLI
This app was generated using the Vue-CLI
* https://vuejs.org/v2/guide/installation.html#CLI
* https://github.com/vuejs/vue-cli

## Plot & Histogram
* https://github.com/ankane/vue-chartkick
