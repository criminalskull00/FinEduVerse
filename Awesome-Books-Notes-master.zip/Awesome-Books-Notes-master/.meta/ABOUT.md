# Roadmap

# Milestone V2

- [ ] 移除所有存在潜在侵权的副本

# Milestone V1

- [ ] 整理当前系统下目录文件，将已收录书籍的原链接添加到目录中

- [ ] [E-Books](https://github.com/kiner-shah/E-Books)

- [ ] 将 https://github.com/oneforce/book-warehouse 中的内容收录进来

- [ ] 归档 http://books.goalkicker.com/ 中涉及的书籍

- [ ] 归档 https://github.com/dariubs/GoBooks 中的内容

- [ ] 归档 https://github.com/rohanchikorde/Data-Science-books
