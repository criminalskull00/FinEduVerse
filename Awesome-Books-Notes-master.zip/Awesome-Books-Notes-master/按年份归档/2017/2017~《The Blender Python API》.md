> 参考地址：https://cdn.oiipdf.com/pdf/13ba4c56-2b91-469f-aabe-5c7fa1e6b1b4.pdf，代码地址：https://github.com/Apress/blender-python-api

# The Blender Python API
