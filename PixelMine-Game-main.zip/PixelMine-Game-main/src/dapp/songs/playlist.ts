const pixelMineAudio = require("./pixel-mine.mp3");

export const playlist = [
  {
    name: "Pixel Mine Audio",
    file: pixelMineAudio,
    artist: "Musicion",
  },
];
